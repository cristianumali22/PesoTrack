# PesoTrack

Offline personal finance tracker for Android (Kotlin, Jetpack Compose, Room, WorkManager, Glance).

## Open & run
1. Android Studio (Ladybug or newer) -> **Open** this folder. Let Gradle sync (it downloads the wrapper JAR).
2. Run the `app` configuration on a device/emulator (API 26+).
3. Long-press the home screen -> Widgets -> **PesoTrack** to add the quick-record widget.

## Features
| Requirement | Where |
|---|---|
| Wallets, default PHP, add balance | `ui/WalletEditorScreen.kt`, `ui/WalletDetailScreen.kt` |
| Spend / withdraw / transfer deduct from balance | `data/Repository.kt` (`record`, `transfer`) |
| Bank / e-wallet / digital bank / credit card templates | `data/Templates.kt`, drawn by `WalletCardView` in `ui/Components.kt` |
| Installments (where, how much, due date) | `ui/InstallmentsScreen.kt` |
| Notify 5 days before due | `notify/Reminders.kt` (daily 9:00 AM worker, `REMINDER_DAYS = 5`) |
| Interest per annum | wallet field; credited automatically on app open (`Repository.accrueAll`) |
| Home-screen widget | `widget/QuickAddWidget.kt` + `QuickAddActivity.kt` |
| Offline assistant | `chat/ChatEngine.kt` (rule-based, on-device) |

## Notes
- Money is stored as integer centavos.
- Interest is simple daily accrual (balance x rate / 365) net of a configurable tax (default 20% PH final tax).
  Real banks differ (tiered rates, monthly crediting) — treat it as an estimate.
- Card designs are drawn in code (gradients) to resemble the templates; drop real artwork in by
  replacing `WalletCardView`'s background with an `Image(painterResource(...))` per template id.
- Assistant: implement `ChatEngine` with an on-device LLM (MediaPipe LLM Inference / Gemini Nano) later;
  the confirm-before-saving UI keeps working.
- Unit tests: `./gradlew test` (chat parser).
