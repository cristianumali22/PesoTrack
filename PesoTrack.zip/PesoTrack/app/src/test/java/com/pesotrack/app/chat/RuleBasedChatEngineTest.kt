package com.pesotrack.app.chat

import com.pesotrack.app.data.Wallet
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RuleBasedChatEngineTest {
    private val wallets = listOf(
        Wallet(id = 1, name = "GCash", templateId = "ew_gcash", balance = 100_000),
        Wallet(id = 2, name = "BDO Savings", templateId = "bank_bdo", balance = 500_000),
        Wallet(id = 3, name = "BPI", templateId = "bank_bpi", balance = 200_000),
    )

    private fun ask(text: String) = runBlocking { RuleBasedChatEngine().handle(text, wallets) }

    @Test fun spendWithNote() {
        val a = ask("spent 250 on lunch from gcash").actions.single() as ChatAction.Withdraw
        assertEquals(1L, a.walletId); assertEquals(25_000L, a.amount); assertEquals("Lunch", a.note)
    }

    @Test fun multipleDeposits() {
        val acts = ask("Add 5,000 to BDO Savings, 2000 to gcash").actions
        assertEquals(2, acts.size)
        assertEquals(500_000L, (acts[0] as ChatAction.Deposit).amount)
        assertEquals(1L, (acts[1] as ChatAction.Deposit).walletId)
    }

    @Test fun transferDirection() {
        val t = ask("transfer 1k from bpi to gcash").actions.single() as ChatAction.Transfer
        assertEquals(3L, t.fromId); assertEquals(1L, t.toId); assertEquals(100_000L, t.amount)
        val r = ask("transfer 500 to bpi from gcash").actions.single() as ChatAction.Transfer
        assertEquals(1L, r.fromId); assertEquals(3L, r.toId)
    }

    @Test fun balanceQuery() {
        assertTrue(ask("what's my balance?").text.contains("GCash"))
        assertTrue(ask("what's my balance?").actions.isEmpty())
    }

    @Test fun missingWalletAsksWhich() {
        val r = ask("spent 100 on jeep")
        assertTrue(r.actions.isEmpty()); assertTrue(r.text.contains("which wallet"))
    }
}
