package com.pesotrack.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.pesotrack.app.AppViewModel
import com.pesotrack.app.data.Fmt
import com.pesotrack.app.data.Money
import com.pesotrack.app.data.Templates
import com.pesotrack.app.data.TxType
import kotlin.math.roundToLong

@Composable
fun ScreenHeader(title: String, onBack: (() -> Unit)?, actions: @Composable () -> Unit = {}) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        if (onBack != null) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
        }
        Text(title, style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f).padding(start = if (onBack == null) 12.dp else 0.dp))
        actions()
    }
}

@Composable
fun WalletDetailScreen(vm: AppViewModel, walletId: Long, onBack: () -> Unit, onEdit: (Long) -> Unit) {
    val wallet by remember(walletId) { vm.wallet(walletId) }.collectAsStateWithLifecycle(initialValue = null)
    val txs by remember(walletId) { vm.walletTx(walletId) }.collectAsStateWithLifecycle(initialValue = emptyList())
    val allWallets by vm.wallets.collectAsStateWithLifecycle()
    var dialogType by remember { mutableStateOf<TxType?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }

    val w = wallet
    Column(Modifier.fillMaxSize()) {
        ScreenHeader(w?.name ?: "Wallet", onBack) {
            if (w != null) {
                IconButton(onClick = { onEdit(w.id) }) { Icon(Icons.Filled.Edit, contentDescription = "Edit") }
                IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Filled.Delete, contentDescription = "Delete") }
            }
        }
        if (w == null) return@Column

        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                val tpl = Templates.byId(w.templateId) ?: Templates.all.first()
                WalletCardView(tpl, title = w.name, subtitle = Money.format(w.balance, w.currency))
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { dialogType = TxType.DEPOSIT }, modifier = Modifier.weight(1f)) { Text("Add") }
                    OutlinedButton(onClick = { dialogType = TxType.WITHDRAW }, modifier = Modifier.weight(1f)) { Text("Spend") }
                    OutlinedButton(onClick = { dialogType = TxType.TRANSFER_OUT }, modifier = Modifier.weight(1f)) { Text("Transfer") }
                }
            }
            val rate = w.interestRatePa
            if (rate != null) {
                item {
                    val net = 1 - w.interestTaxPct / 100.0
                    val yearly = (w.balance * rate / 100.0 * net).roundToLong()
                    val monthly = (w.balance * rate / 100.0 / 12.0 * net).roundToLong()
                    Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.primaryContainer) {
                        Column(Modifier.fillMaxWidth().padding(16.dp)) {
                            Text("Earning ${Fmt.rate(rate)}% per annum", fontWeight = FontWeight.SemiBold)
                            Text(
                                "≈ ${Money.format(monthly, w.currency)} / month · ${Money.format(yearly, w.currency)} / year " +
                                    "(after ${Fmt.rate(w.interestTaxPct)}% tax, at the current balance)",
                                style = MaterialTheme.typography.bodySmall,
                            )
                            Text(
                                "Interest is credited automatically each time you open the app.",
                                style = MaterialTheme.typography.bodySmall,
                            )
                        }
                    }
                }
            }
            item { Text("Transactions", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 4.dp)) }
            if (txs.isEmpty()) item { Text("Nothing yet.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            items(txs, key = { it.id }) { tx -> TxRow(tx, null, w.currency) }
        }
    }

    dialogType?.let { type ->
        Dialog(onDismissRequest = { dialogType = null }) {
            Surface(shape = RoundedCornerShape(24.dp)) {
                TransactionForm(allWallets.orEmpty(), type, walletId, vm::submit) { dialogType = null }
            }
        }
    }

    if (confirmDelete && w != null) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Delete ${w.name}?") },
            text = { Text("This removes the wallet and all of its transactions. This can't be undone.") },
            confirmButton = {
                TextButton(onClick = { confirmDelete = false; vm.deleteWallet(w) { onBack() } }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } },
        )
    }
}
