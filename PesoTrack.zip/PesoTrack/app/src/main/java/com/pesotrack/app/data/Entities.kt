package com.pesotrack.app.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import java.time.LocalDate

enum class TxType(val credit: Boolean, val label: String) {
    DEPOSIT(true, "Added"),
    WITHDRAW(false, "Spent"),
    TRANSFER_OUT(false, "Transfer out"),
    TRANSFER_IN(true, "Transfer in"),
    INTEREST(true, "Interest"),
    INSTALLMENT(false, "Installment"),
}

/** All money is stored as integer centavos (₱1.00 = 100) to avoid floating-point drift. */
@Entity(tableName = "wallets")
data class Wallet(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val templateId: String,
    val balance: Long,
    val currency: String = "PHP",
    /** Interest rate per annum in percent (e.g. 4.5). Null = no interest. */
    val interestRatePa: Double? = null,
    /** Final withholding tax on interest, percent (PH deposits are typically 20%). */
    val interestTaxPct: Double = 20.0,
    /** Epoch day up to which interest has been credited. */
    val lastAccrualDate: Long = LocalDate.now().toEpochDay(),
    /** Credit cards only: day of month the statement payment is due. */
    val creditDueDay: Int? = null,
    /** Credit cards only: next payment due date (epoch day). */
    val nextCreditDueDate: Long? = null,
    /** Due date we last sent a payment reminder for. */
    val lastCreditNotifiedDue: Long = -1,
)

@Entity(
    tableName = "transactions",
    foreignKeys = [ForeignKey(
        entity = Wallet::class,
        parentColumns = ["id"],
        childColumns = ["walletId"],
        onDelete = ForeignKey.CASCADE,
    )],
    indices = [Index("walletId")],
)
data class Tx(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val walletId: Long,
    val type: TxType,
    val amount: Long, // always positive; direction comes from type
    val note: String = "",
    val counterpartWalletId: Long? = null,
    val timestamp: Long = System.currentTimeMillis(),
)

@Entity(tableName = "installments")
data class Installment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    /** Where it's happening: store, lender, card, etc. */
    val place: String,
    /** Amount per payment (centavos). */
    val amount: Long,
    /** Next due date (epoch day). */
    val dueDate: Long,
    /** Day of month the payment falls on (used to roll to next month without drift). */
    val dueDay: Int,
    val remainingPayments: Int,
    /** Wallet normally used to pay this. */
    val walletId: Long? = null,
    /** Due date we last sent a reminder for (avoids duplicate notifications). */
    val lastNotifiedDue: Long = -1,
)
