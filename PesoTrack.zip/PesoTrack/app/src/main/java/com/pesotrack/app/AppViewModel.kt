package com.pesotrack.app

import android.app.Application
import androidx.compose.runtime.mutableStateListOf
import androidx.glance.appwidget.updateAll
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.pesotrack.app.chat.ChatAction
import com.pesotrack.app.chat.ChatEngine
import com.pesotrack.app.chat.RuleBasedChatEngine
import com.pesotrack.app.data.AppDatabase
import com.pesotrack.app.data.Installment
import com.pesotrack.app.data.Repository
import com.pesotrack.app.data.TxType
import com.pesotrack.app.data.Wallet
import com.pesotrack.app.notify.Reminders
import com.pesotrack.app.widget.QuickAddWidget
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class ChatMsg(
    val id: Long,
    val fromUser: Boolean,
    val text: String,
    val pending: List<ChatAction> = emptyList(),
    val state: State = State.NONE,
) {
    enum class State { NONE, CONFIRMED, CANCELLED }
}

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = Repository(AppDatabase.get(app))

    /** Swap this for an on-device LLM-backed engine if you add one. */
    private val engine: ChatEngine = RuleBasedChatEngine()

    /** null = still loading from the database. */
    val wallets: StateFlow<List<Wallet>?> =
        repo.allWallets.stateIn(viewModelScope, SharingStarted.Eagerly, null)
    val recent = repo.recent.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val installments = repo.installments.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val chat = mutableStateListOf<ChatMsg>()
    private var nextMsgId = 1L

    init {
        viewModelScope.launch { repo.accrueAll(); refreshWidget() }
    }

    fun wallet(id: Long) = repo.wallet(id)
    fun walletTx(id: Long) = repo.walletTx(id)
    fun cardSpent(id: Long) = repo.cardSpent(id)
    suspend fun loadWallet(id: Long) = repo.getWallet(id)

    // ---- wallets ----

    fun saveWallet(w: Wallet, onDone: (Long) -> Unit = {}) {
        viewModelScope.launch {
            val id = if (w.id == 0L) repo.addWallet(w) else { repo.updateWallet(w); w.id }
            refreshWidget()
            onDone(id)
        }
    }

    fun deleteWallet(w: Wallet, onDone: () -> Unit = {}) {
        viewModelScope.launch { repo.deleteWallet(w); refreshWidget(); onDone() }
    }

    // ---- transactions ----

    /** [type] is DEPOSIT, WITHDRAW or TRANSFER_OUT (which needs [toWalletId]). */
    fun submit(type: TxType, walletId: Long, toWalletId: Long?, amount: Long, note: String, onResult: (String?) -> Unit) {
        viewModelScope.launch {
            val err = if (type == TxType.TRANSFER_OUT) {
                if (toWalletId == null) "Choose a destination wallet" else repo.transfer(walletId, toWalletId, amount, note)
            } else {
                repo.record(walletId, type, amount, note)
            }
            if (err == null) refreshWidget()
            onResult(err)
        }
    }

    // ---- installments ----

    fun addInstallment(i: Installment) {
        viewModelScope.launch {
            repo.addInstallment(i)
            Reminders.runNow(getApplication()) // notifies immediately if it's already within 5 days
        }
    }

    fun deleteInstallment(i: Installment) {
        viewModelScope.launch { repo.deleteInstallment(i) }
    }

    fun payInstallment(i: Installment, walletId: Long?, onResult: (String?) -> Unit) {
        viewModelScope.launch {
            val err = repo.payInstallment(i, walletId)
            if (err == null) refreshWidget()
            onResult(err)
        }
    }

    // ---- assistant ----

    fun sendChat(text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        chat.add(ChatMsg(nextMsgId++, true, t))
        viewModelScope.launch {
            val reply = engine.handle(t, wallets.value.orEmpty())
            chat.add(ChatMsg(nextMsgId++, false, reply.text, reply.actions))
        }
    }

    fun confirm(msgId: Long) {
        val idx = chat.indexOfFirst { it.id == msgId }
        if (idx < 0) return
        val msg = chat[idx]
        if (msg.state != ChatMsg.State.NONE) return
        chat[idx] = msg.copy(state = ChatMsg.State.CONFIRMED)
        viewModelScope.launch {
            val errors = msg.pending.mapNotNull { a ->
                when (a) {
                    is ChatAction.Deposit -> repo.record(a.walletId, TxType.DEPOSIT, a.amount, a.note)
                    is ChatAction.Withdraw -> repo.record(a.walletId, TxType.WITHDRAW, a.amount, a.note)
                    is ChatAction.Transfer -> repo.transfer(a.fromId, a.toId, a.amount, a.note)
                }
            }
            refreshWidget()
            val text = if (errors.isEmpty()) "Done ✓ Recorded ${msg.pending.size} item(s)."
            else "Recorded what I could, but:\n" + errors.joinToString("\n") { "• $it" }
            chat.add(ChatMsg(nextMsgId++, false, text))
        }
    }

    fun cancel(msgId: Long) {
        val idx = chat.indexOfFirst { it.id == msgId }
        if (idx >= 0 && chat[idx].state == ChatMsg.State.NONE) {
            chat[idx] = chat[idx].copy(state = ChatMsg.State.CANCELLED)
        }
    }

    private fun refreshWidget() {
        viewModelScope.launch {
            try { QuickAddWidget().updateAll(getApplication()) } catch (_: Exception) { }
        }
    }
}
