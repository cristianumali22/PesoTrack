package com.pesotrack.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.pesotrack.app.AppViewModel
import com.pesotrack.app.data.Fmt
import com.pesotrack.app.data.Installment
import com.pesotrack.app.data.Money
import com.pesotrack.app.data.Wallet
import com.pesotrack.app.notify.REMINDER_DAYS
import java.time.LocalDate

@Composable
fun InstallmentsScreen(vm: AppViewModel) {
    val items by vm.installments.collectAsStateWithLifecycle()
    val wallets = vm.wallets.collectAsStateWithLifecycle().value.orEmpty()
    var showAdd by remember { mutableStateOf(false) }
    var payTarget by remember { mutableStateOf<Installment?>(null) }
    val today = LocalDate.now().toEpochDay()

    val active = items.filter { it.remainingPayments > 0 }.sortedBy { it.dueDate }
    val done = items.filter { it.remainingPayments <= 0 }
    val nextMonth = active.filter { it.dueDate - today <= 30 }.sumOf { it.amount }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                Column {
                    Text("Installments", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    Text(
                        "Due in the next 30 days: ${Money.format(nextMonth)}",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Text(
                        "You'll get a notification $REMINDER_DAYS days before each due date.",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            if (items.isEmpty()) item { Text("No installments yet. Tap “Add installment”.") }
            items(active + done, key = { it.id }) { i ->
                InstallmentCard(i, today, onPay = { payTarget = i }, onDelete = { vm.deleteInstallment(i) })
            }
        }
        ExtendedFloatingActionButton(
            onClick = { showAdd = true },
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp),
            icon = { Icon(Icons.Filled.Add, contentDescription = null) },
            text = { Text("Add installment") },
        )
    }

    if (showAdd) {
        Dialog(onDismissRequest = { showAdd = false }) {
            Surface(shape = RoundedCornerShape(24.dp)) {
                AddInstallmentForm(wallets, onSave = { vm.addInstallment(it); showAdd = false }, onDismiss = { showAdd = false })
            }
        }
    }

    payTarget?.let { inst -> PayDialog(vm, inst, wallets) { payTarget = null } }
}

@Composable
private fun InstallmentCard(i: Installment, today: Long, onPay: () -> Unit, onDelete: () -> Unit) {
    val left = (i.dueDate - today).toInt()
    val finished = i.remainingPayments <= 0
    val soon = !finished && left <= REMINDER_DAYS
    val dueText = when {
        finished -> "Fully paid"
        left < 0 -> "Overdue by ${-left} day(s) · was ${Fmt.date(i.dueDate)}"
        left == 0 -> "Due today"
        left == 1 -> "Due tomorrow · ${Fmt.date(i.dueDate)}"
        else -> "Due ${Fmt.date(i.dueDate)} · in $left days"
    }
    Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surface, tonalElevation = 1.dp) {
        Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(i.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Text(i.place, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Text(Money.format(i.amount), fontWeight = FontWeight.Bold)
                IconButton(onClick = onDelete) { Icon(Icons.Filled.Delete, contentDescription = "Delete") }
            }
            Text(
                dueText,
                color = if (soon) Negative else MaterialTheme.colorScheme.onSurfaceVariant,
                fontWeight = if (soon) FontWeight.SemiBold else FontWeight.Normal,
            )
            if (!finished) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("${i.remainingPayments} payment(s) left", modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                    Button(onClick = onPay) { Text("Mark paid") }
                }
            }
        }
    }
}

@Composable
private fun PayDialog(vm: AppViewModel, inst: Installment, wallets: List<Wallet>, onClose: () -> Unit) {
    var walletId by remember { mutableStateOf(inst.walletId) }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Mark ${inst.name} as paid") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("${Money.format(inst.amount)} — deduct it from a wallet?")
                WalletPicker("Pay from", wallets, walletId, { walletId = it }, allowNone = true)
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                vm.payInstallment(inst, walletId) { err -> if (err == null) onClose() else error = err }
            }) { Text("Confirm") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Cancel") } },
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddInstallmentForm(wallets: List<Wallet>, onSave: (Installment) -> Unit, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var place by remember { mutableStateOf("") }
    var amountText by remember { mutableStateOf("") }
    var countText by remember { mutableStateOf("12") }
    var dueEpoch by remember { mutableStateOf(LocalDate.now().plusDays(7).toEpochDay()) }
    var walletId by remember { mutableStateOf<Long?>(null) }
    var showPicker by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Add installment", style = MaterialTheme.typography.titleLarge)
        OutlinedTextField(name, { name = it }, label = { Text("What is it? (e.g. iPhone 15)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(place, { place = it }, label = { Text("Where? (store / lender / card)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(
            amountText, { amountText = it }, label = { Text("Amount per payment") }, prefix = { Text("₱") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, modifier = Modifier.fillMaxWidth(),
        )
        OutlinedTextField(
            countText, { countText = it }, label = { Text("Payments remaining") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.fillMaxWidth(),
        )
        OutlinedButton(onClick = { showPicker = true }, modifier = Modifier.fillMaxWidth()) {
            Text("Next due date: ${Fmt.date(dueEpoch)}")
        }
        WalletPicker("Usually paid from", wallets, walletId, { walletId = it }, allowNone = true)
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        Spacer(Modifier.height(4.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            TextButton(onClick = onDismiss) { Text("Cancel") }
            Button(onClick = {
                val amt = Money.parse(amountText)
                val count = countText.trim().toIntOrNull()
                if (name.isBlank()) {
                    error = "Enter a name"
                } else if (amt == null || amt <= 0) {
                    error = "Enter a valid amount"
                } else if (count == null || count < 1) {
                    error = "Payments remaining must be at least 1"
                } else {
                    onSave(
                        Installment(
                            name = name.trim(), place = place.trim().ifBlank { "—" }, amount = amt,
                            dueDate = dueEpoch, dueDay = LocalDate.ofEpochDay(dueEpoch).dayOfMonth,
                            remainingPayments = count, walletId = walletId,
                        )
                    )
                }
            }) { Text("Save") }
        }
    }

    if (showPicker) {
        val state = rememberDatePickerState(initialSelectedDateMillis = dueEpoch * 86_400_000L)
        DatePickerDialog(
            onDismissRequest = { showPicker = false },
            confirmButton = {
                TextButton(onClick = {
                    state.selectedDateMillis?.let { dueEpoch = it / 86_400_000L }
                    showPicker = false
                }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { showPicker = false }) { Text("Cancel") } },
        ) { DatePicker(state = state) }
    }
}
