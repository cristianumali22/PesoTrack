package com.pesotrack.app.data

import org.json.JSONArray
import org.json.JSONObject

/** Everything a backup file needs to fully restore the app's data. */
data class BackupData(
    val wallets: List<Wallet>,
    val transactions: List<Tx>,
    val installments: List<Installment>,
    val bills: List<Bill> = emptyList(),
)

/**
 * Plain JSON export/import so you can back up before installing an update (schema changes
 * currently wipe the database) and restore afterwards. Uses org.json, which ships with Android,
 * so this file adds no extra dependency and no extra file permission — export/import happen
 * through the system file picker (Storage Access Framework).
 */
object Backup {
    private const val FORMAT_VERSION = 1

    fun toJson(data: BackupData): String {
        val root = JSONObject()
        root.put("formatVersion", FORMAT_VERSION)
        root.put("exportedAt", System.currentTimeMillis())

        val wallets = JSONArray()
        data.wallets.forEach { w ->
            wallets.put(
                JSONObject().apply {
                    put("id", w.id)
                    put("name", w.name)
                    put("templateId", w.templateId)
                    put("balance", w.balance)
                    put("currency", w.currency)
                    put("interestRatePa", w.interestRatePa ?: JSONObject.NULL)
                    put("interestTaxPct", w.interestTaxPct)
                    put("lastAccrualDate", w.lastAccrualDate)
                    put("creditLimit", w.creditLimit ?: JSONObject.NULL)
                    put("creditStatementDay", w.creditStatementDay ?: JSONObject.NULL)
                    put("nextStatementDate", w.nextStatementDate ?: JSONObject.NULL)
                    put("creditDueDay", w.creditDueDay ?: JSONObject.NULL)
                    put("nextCreditDueDate", w.nextCreditDueDate ?: JSONObject.NULL)
                    put("lastCreditNotifiedDue", w.lastCreditNotifiedDue)
                    put("spendCycleStart", w.spendCycleStart)
                    put("lastCardPaymentAmount", w.lastCardPaymentAmount ?: JSONObject.NULL)
                    put("lastCardPaymentDate", w.lastCardPaymentDate ?: JSONObject.NULL)
                }
            )
        }
        root.put("wallets", wallets)

        val txs = JSONArray()
        data.transactions.forEach { t ->
            txs.put(
                JSONObject().apply {
                    put("id", t.id)
                    put("walletId", t.walletId)
                    put("type", t.type.name)
                    put("amount", t.amount)
                    put("note", t.note)
                    put("counterpartWalletId", t.counterpartWalletId ?: JSONObject.NULL)
                    put("timestamp", t.timestamp)
                }
            )
        }
        root.put("transactions", txs)

        val installments = JSONArray()
        data.installments.forEach { i ->
            installments.put(
                JSONObject().apply {
                    put("id", i.id)
                    put("name", i.name)
                    put("place", i.place)
                    put("amount", i.amount)
                    put("dueDate", i.dueDate)
                    put("dueDay", i.dueDay)
                    put("remainingPayments", i.remainingPayments)
                    put("walletId", i.walletId ?: JSONObject.NULL)
                    put("lastNotifiedDay", i.lastNotifiedDay)
                }
            )
        }
        root.put("installments", installments)

        val bills = JSONArray()
        data.bills.forEach { b ->
            bills.put(
                JSONObject().apply {
                    put("id", b.id)
                    put("name", b.name)
                    put("amount", b.amount)
                    put("dueDate", b.dueDate)
                    put("dueDay", b.dueDay)
                    put("walletId", b.walletId ?: JSONObject.NULL)
                    put("lastNotifiedDay", b.lastNotifiedDay)
                }
            )
        }
        root.put("bills", bills)

        return root.toString(2)
    }

    fun fromJson(json: String): BackupData {
        val root = JSONObject(json)

        val wallets = root.getJSONArray("wallets").let { arr ->
            (0 until arr.length()).map { idx ->
                val o = arr.getJSONObject(idx)
                Wallet(
                    id = o.getLong("id"),
                    name = o.getString("name"),
                    templateId = o.getString("templateId"),
                    balance = o.getLong("balance"),
                    currency = o.getString("currency"),
                    interestRatePa = if (o.isNull("interestRatePa")) null else o.getDouble("interestRatePa"),
                    interestTaxPct = o.optDouble("interestTaxPct", 20.0),
                    lastAccrualDate = o.getLong("lastAccrualDate"),
                    creditLimit = if (o.isNull("creditLimit")) null else o.getLong("creditLimit"),
                    creditStatementDay = if (o.isNull("creditStatementDay")) null else o.getInt("creditStatementDay"),
                    nextStatementDate = if (o.isNull("nextStatementDate")) null else o.getLong("nextStatementDate"),
                    creditDueDay = if (o.isNull("creditDueDay")) null else o.getInt("creditDueDay"),
                    nextCreditDueDate = if (o.isNull("nextCreditDueDate")) null else o.getLong("nextCreditDueDate"),
                    lastCreditNotifiedDue = o.optLong("lastCreditNotifiedDue", -1),
                    spendCycleStart = o.optLong("spendCycleStart", 0L),
                    lastCardPaymentAmount = if (o.isNull("lastCardPaymentAmount")) null else o.getLong("lastCardPaymentAmount"),
                    lastCardPaymentDate = if (o.isNull("lastCardPaymentDate")) null else o.getLong("lastCardPaymentDate"),
                )
            }
        }

        val txs = root.getJSONArray("transactions").let { arr ->
            (0 until arr.length()).map { idx ->
                val o = arr.getJSONObject(idx)
                Tx(
                    id = o.getLong("id"),
                    walletId = o.getLong("walletId"),
                    type = TxType.valueOf(o.getString("type")),
                    amount = o.getLong("amount"),
                    note = o.optString("note", ""),
                    counterpartWalletId = if (o.isNull("counterpartWalletId")) null else o.getLong("counterpartWalletId"),
                    timestamp = o.getLong("timestamp"),
                )
            }
        }

        val installments = root.getJSONArray("installments").let { arr ->
            (0 until arr.length()).map { idx ->
                val o = arr.getJSONObject(idx)
                Installment(
                    id = o.getLong("id"),
                    name = o.getString("name"),
                    place = o.getString("place"),
                    amount = o.getLong("amount"),
                    dueDate = o.getLong("dueDate"),
                    dueDay = o.getInt("dueDay"),
                    remainingPayments = o.getInt("remainingPayments"),
                    walletId = if (o.isNull("walletId")) null else o.getLong("walletId"),
                    lastNotifiedDay = o.optLong("lastNotifiedDay", -1),
                )
            }
        }

        val bills = if (root.has("bills")) {
            root.getJSONArray("bills").let { arr ->
                (0 until arr.length()).map { idx ->
                    val o = arr.getJSONObject(idx)
                    Bill(
                        id = o.getLong("id"),
                        name = o.getString("name"),
                        amount = o.getLong("amount"),
                        dueDate = o.getLong("dueDate"),
                        dueDay = o.getInt("dueDay"),
                        walletId = if (o.isNull("walletId")) null else o.getLong("walletId"),
                        lastNotifiedDay = o.optLong("lastNotifiedDay", -1),
                    )
                }
            }
        } else {
            emptyList()
        }

        return BackupData(wallets, txs, installments, bills)
    }
}
