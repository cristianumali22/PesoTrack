package com.pesotrack.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pesotrack.app.data.CardTemplate
import com.pesotrack.app.data.Category
import com.pesotrack.app.data.Fmt
import com.pesotrack.app.data.Money
import com.pesotrack.app.data.Network
import com.pesotrack.app.data.Tx
import com.pesotrack.app.data.TxType
import com.pesotrack.app.data.Wallet

/** A payment-card style tile, drawn from a [CardTemplate]. */
@Composable
fun WalletCardView(
    t: CardTemplate,
    modifier: Modifier = Modifier,
    title: String? = null,
    subtitle: String? = null,
    compact: Boolean = false,
    selected: Boolean = false,
) {
    val fg = if (t.darkBg) Color.White else Color(0xFF1B1B1F)
    val pad = if (compact) 10.dp else 16.dp
    val shape = RoundedCornerShape(if (compact) 14.dp else 22.dp)
    Box(
        modifier
            .fillMaxWidth()
            .aspectRatio(1.586f)
            .clip(shape)
            .background(Brush.linearGradient(t.colors.map { Color(it) }))
            .then(if (selected) Modifier.border(3.dp, Sage, shape) else Modifier)
    ) {
        Text(
            t.label, color = fg, fontWeight = FontWeight.ExtraBold,
            fontSize = if (compact) 13.sp else 20.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.align(Alignment.TopStart).padding(pad),
        )
        if (t.category != Category.CASH && t.category != Category.EWALLET) {
            Box(
                Modifier
                    .align(Alignment.CenterStart).padding(start = pad)
                    .size(if (compact) 26.dp else 40.dp, if (compact) 20.dp else 30.dp)
                    .clip(RoundedCornerShape(5.dp))
                    .background(Brush.linearGradient(listOf(Color(0xFFF3D98B), Color(0xFFC9A24A))))
            )
        }
        Column(Modifier.align(Alignment.BottomStart).padding(pad)) {
            title?.let {
                Text(it, color = fg.copy(alpha = 0.85f), fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            subtitle?.let { Text(it, color = fg, fontWeight = FontWeight.Bold, fontSize = 22.sp) }
        }
        NetworkMark(t.network, fg, compact, Modifier.align(Alignment.BottomEnd).padding(pad))
        if (selected) {
            Icon(
                Icons.Filled.CheckCircle, contentDescription = "Selected", tint = Sage,
                modifier = Modifier.align(Alignment.TopEnd).padding(6.dp).background(Color.White, CircleShape),
            )
        }
    }
}

@Composable
private fun NetworkMark(n: Network, fg: Color, compact: Boolean, modifier: Modifier) {
    val s = if (compact) 16.dp else 28.dp
    when (n) {
        Network.MASTERCARD -> Box(modifier.width(s * 1.6f).height(s)) {
            Box(Modifier.size(s).clip(CircleShape).background(Color(0xFFE53935)))
            Box(Modifier.size(s).offset(x = s * 0.6f).clip(CircleShape).background(Color(0xCCFFA000)))
        }
        Network.VISA -> Text(
            "VISA", modifier = modifier, color = fg, fontStyle = FontStyle.Italic,
            fontWeight = FontWeight.Black, fontSize = if (compact) 12.sp else 20.sp,
        )
        Network.JCB -> Text(
            "JCB", modifier = modifier, color = fg, fontWeight = FontWeight.Black,
            fontSize = if (compact) 12.sp else 18.sp,
        )
        Network.NONE -> {}
    }
}

@Composable
fun WalletPicker(
    label: String,
    wallets: List<Wallet>,
    selectedId: Long?,
    onSelect: (Long?) -> Unit,
    modifier: Modifier = Modifier,
    allowNone: Boolean = false,
) {
    var open by remember { mutableStateOf(false) }
    val sel = wallets.firstOrNull { it.id == selectedId }
    Box(modifier.fillMaxWidth()) {
        OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) {
            Text(
                "$label: " + (sel?.let { "${it.name} · ${Money.format(it.balance, it.currency)}" } ?: "None"),
                maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false),
            )
            Icon(Icons.Filled.ArrowDropDown, contentDescription = null)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            if (allowNone) {
                DropdownMenuItem(text = { Text("Don't deduct from a wallet") }, onClick = { onSelect(null); open = false })
            }
            wallets.forEach { w ->
                DropdownMenuItem(
                    text = { Text("${w.name} · ${Money.format(w.balance, w.currency)}") },
                    onClick = { onSelect(w.id); open = false },
                )
            }
        }
    }
}

/** Add balance / Spend / Transfer form, shared by the app and the widget popup. */
@Composable
fun TransactionForm(
    wallets: List<Wallet>,
    initialType: TxType,
    initialWalletId: Long?,
    onSubmit: (type: TxType, walletId: Long, toWalletId: Long?, amount: Long, note: String, onResult: (String?) -> Unit) -> Unit,
    onDismiss: () -> Unit,
) {
    var type by remember { mutableStateOf(initialType) }
    var walletId by remember { mutableStateOf(initialWalletId ?: wallets.firstOrNull()?.id) }
    var toId by remember { mutableStateOf<Long?>(null) }
    var amountText by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    val wallet = wallets.firstOrNull { it.id == walletId }

    Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Record transaction", style = MaterialTheme.typography.titleLarge)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(TxType.WITHDRAW to "Spend", TxType.DEPOSIT to "Add", TxType.TRANSFER_OUT to "Transfer").forEach { (t, l) ->
                FilterChip(selected = type == t, onClick = { type = t }, label = { Text(l) })
            }
        }
        WalletPicker(
            label = if (type == TxType.TRANSFER_OUT) "From" else "Wallet",
            wallets = wallets, selectedId = walletId, onSelect = { walletId = it },
        )
        if (type == TxType.TRANSFER_OUT) {
            WalletPicker("To", wallets.filter { it.id != walletId }, toId, { toId = it })
        }
        OutlinedTextField(
            value = amountText, onValueChange = { amountText = it },
            label = { Text("Amount (${wallet?.currency ?: "PHP"})") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            singleLine = true, modifier = Modifier.fillMaxWidth(),
        )
        OutlinedTextField(
            value = note, onValueChange = { note = it },
            label = { Text("Note (optional)") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
        )
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            TextButton(onClick = onDismiss) { Text("Cancel") }
            Button(onClick = {
                val amt = Money.parse(amountText)
                val id = walletId
                if (id == null) {
                    error = "Choose a wallet"
                } else if (amt == null || amt <= 0) {
                    error = "Enter a valid amount"
                } else {
                    onSubmit(type, id, toId, amt, note.trim()) { err ->
                        if (err == null) onDismiss() else error = err
                    }
                }
            }) { Text("Save") }
        }
    }
}

@Composable
fun TxRow(tx: Tx, walletName: String?, currency: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(tx.note.ifBlank { tx.type.label }, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                tx.type.label + (walletName?.let { " · $it" } ?: "") + " · " + Fmt.dateTime(tx.timestamp),
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Spacer(Modifier.width(8.dp))
        Text(
            (if (tx.type.credit) "+" else "−") + Money.format(tx.amount, currency),
            color = if (tx.type.credit) Positive else Negative, fontWeight = FontWeight.SemiBold,
        )
    }
}
