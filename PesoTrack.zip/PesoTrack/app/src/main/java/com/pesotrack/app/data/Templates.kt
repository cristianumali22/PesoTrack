package com.pesotrack.app.data

enum class Category(val label: String) {
    BANK("Banks"),
    CREDIT("Credit Cards"),
    DIGITAL("Digital Banks"),
    EWALLET("E-Wallets"),
    CASH("Cash"),
}

enum class Network { NONE, MASTERCARD, VISA, JCB }

/** A selectable card design. Colours are ARGB longs so this file stays free of Compose deps. */
data class CardTemplate(
    val id: String,
    val label: String,
    val category: Category,
    val colors: List<Long>,
    val darkBg: Boolean = true,
    val network: Network = Network.NONE,
)

object Templates {
    private val MC = Network.MASTERCARD
    private val VISA = Network.VISA
    private val JCB = Network.JCB

    private fun t(
        id: String, label: String, cat: Category, c1: Long, c2: Long,
        dark: Boolean = true, net: Network = Network.NONE,
    ) = CardTemplate(id, label, cat, listOf(c1, c2), dark, net)

    private val B = Category.BANK
    private val C = Category.CREDIT
    private val D = Category.DIGITAL
    private val E = Category.EWALLET
    private val K = Category.CASH

    val banks = listOf(
        t("bank_bpi", "BPI", B, 0xFF7A0C0C, 0xFFC62828, net = MC),
        t("bank_bdo", "BDO", B, 0xFF0B2A8A, 0xFF2A5BE0, net = MC),
        t("bank_rcbc", "RCBC", B, 0xFF0A2A66, 0xFF1F55B8, net = JCB),
        t("bank_metrobank", "Metrobank", B, 0xFF3B1A5E, 0xFF8446A8, net = MC),
        t("bank_unionbank", "UnionBank", B, 0xFF1A1A1F, 0xFF45454F, net = VISA),
        t("bank_security", "Security Bank", B, 0xFF0A2F8F, 0xFF1F6BD8, net = MC),
        t("bank_landbank", "Landbank", B, 0xFF0E3B1E, 0xFF3E8E41, net = MC),
        t("bank_eastwest", "EastWest", B, 0xFFDCE24C, 0xFFB4C22A, dark = false, net = VISA),
        t("bank_chinabank", "Chinabank", B, 0xFF7A1010, 0xFFB71C1C, net = VISA),
        t("bank_pnb", "PNB", B, 0xFF1D6F86, 0xFF35A3AA, net = MC),
        t("bank_psbank", "PSBank", B, 0xFFECECEC, 0xFFB9BCC2, dark = false, net = MC),
        t("bank_ucpb", "UCPB", B, 0xFF0D2E9E, 0xFF3B7BE8, net = VISA),
        t("bank_dbp", "DBP", B, 0xFF1B1464, 0xFF8E1B2B),
        t("bank_maybank", "Maybank", B, 0xFF0B0B0B, 0xFF4A3A10),
        t("bank_aub", "AUB", B, 0xFF00563B, 0xFF2E9E6B, net = MC),
        t("bank_other", "Other bank", B, 0xFF37474F, 0xFF78909C),
    )

    private const val GOLD1 = 0xFF9C7A22
    private const val GOLD2 = 0xFFE6C766
    private const val PLAT1 = 0xFF25282F
    private const val PLAT2 = 0xFF5A5F6B

    val credit = listOf(
        t("cc_bdo_gold", "BDO Gold", C, GOLD1, GOLD2, net = MC),
        t("cc_bdo_plat", "BDO Platinum", C, PLAT1, PLAT2, net = MC),
        t("cc_bpi_gold", "BPI Gold", C, GOLD1, GOLD2, net = MC),
        t("cc_bpi_plat", "BPI Platinum", C, PLAT1, PLAT2, net = MC),
        t("cc_ew_gold", "EastWest Gold", C, GOLD1, GOLD2, net = JCB),
        t("cc_ew_plat", "EastWest Platinum", C, PLAT1, PLAT2, net = JCB),
        t("cc_mb_gold", "Metrobank Gold", C, GOLD1, GOLD2, net = MC),
        t("cc_mb_plat", "Metrobank Platinum", C, PLAT1, PLAT2, net = MC),
        t("cc_rcbc_gold", "RCBC Gold", C, GOLD1, GOLD2, net = MC),
        t("cc_rcbc_black", "RCBC Black", C, 0xFF050810, 0xFF12305C, net = VISA),
        t("cc_ub", "UnionBank Credit", C, 0xFFCFE9F5, 0xFFF3DDC8, dark = false, net = MC),
        t("cc_maya", "Maya Credit", C, 0xFF050505, 0xFF262626, net = VISA),
    )

    val digital = listOf(
        t("dg_cimb", "CIMB", D, 0xFFB71C1C, 0xFFE4572E, net = VISA),
        t("dg_gotyme", "GoTyme Bank", D, 0xFF050505, 0xFF1D1D2B, net = VISA),
        t("dg_maribank", "MariBank", D, 0xFFD84315, 0xFFF39C3D, net = MC),
        t("dg_salmon", "Salmon", D, 0xFFE0685A, 0xFFF29A8C, net = MC),
        t("dg_komo", "Komo", D, 0xFF4FC3E0, 0xFF2A9DB5, net = VISA),
        t("dg_tonik", "Tonik", D, 0xFF6D4AE8, 0xFF8E63F0, net = MC),
        t("dg_own", "OWN Bank", D, 0xFF5CC24A, 0xFF8DDA6E, net = MC),
        t("dg_diskartech", "Diskartech", D, 0xFF1E88A8, 0xFFB5C94A, net = MC),
        t("dg_uno", "UNO Digital Bank", D, 0xFF0B0B0F, 0xFF20202B, net = MC),
        t("dg_uniondigital", "UnionDigital", D, 0xFF9B7FE6, 0xFFB7A0F0, net = VISA),
        t("dg_ofbank", "OF Bank", D, 0xFF0B2A8A, 0xFF1F4FC0, net = VISA),
        t("dg_netbank", "Netbank", D, 0xFF17171B, 0xFF3A3A44, net = VISA),
        t("dg_zed", "ZED", D, 0xFFF5D63D, 0xFFF9E77A, dark = false),
    )

    val ewallets = listOf(
        t("ew_gcash", "GCash", E, 0xFF0B5FFF, 0xFF3D8BFF),
        t("ew_maya", "Maya", E, 0xFF0A0A0A, 0xFF1F9D55),
        t("ew_grab", "GrabPay", E, 0xFF00994F, 0xFF33C27A),
        t("ew_shopee", "ShopeePay", E, 0xFFEE4D2D, 0xFFFF7B54),
        t("ew_coins", "Coins.ph", E, 0xFF1058C7, 0xFF3F8BFF),
        t("ew_paypal", "PayPal", E, 0xFF0A2A66, 0xFF2A6CD8),
    )

    val cash = listOf(
        t("cash_black", "Cash", K, 0xFF141414, 0xFF3A3A3A),
        t("cash_pink", "Cash", K, 0xFFE8B4C0, 0xFFF6D6DD, dark = false),
    )

    val all: List<CardTemplate> = banks + credit + digital + ewallets + cash

    private val index = all.associateBy { it.id }
    fun byId(id: String): CardTemplate? = index[id]
    fun inCategory(c: Category) = all.filter { it.category == c }
}
