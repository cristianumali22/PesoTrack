package com.pesotrack.app.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.pesotrack.app.AppViewModel

@Composable
fun App(vm: AppViewModel) {
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route
    val tabs = listOf(
        Triple("home", "Wallets", Icons.Filled.AccountBalanceWallet),
        Triple("installments", "Installments", Icons.Filled.CalendarMonth),
        Triple("chat", "Assistant", Icons.Filled.SmartToy),
    )
    val idArg = listOf(navArgument("id") { type = NavType.LongType })

    Scaffold(
        bottomBar = {
            if (tabs.any { it.first == route }) {
                NavigationBar {
                    tabs.forEach { (r, label, icon) ->
                        NavigationBarItem(
                            selected = route == r,
                            onClick = {
                                nav.navigate(r) {
                                    popUpTo("home")
                                    launchSingleTop = true
                                }
                            },
                            icon = { Icon(icon, contentDescription = label) },
                            label = { Text(label) },
                        )
                    }
                }
            }
        },
    ) { pad ->
        NavHost(nav, startDestination = "home", modifier = Modifier.padding(pad)) {
            composable("home") {
                HomeScreen(vm, onOpenWallet = { nav.navigate("wallet/$it") }, onAddWallet = { nav.navigate("editor/0") })
            }
            composable("installments") { InstallmentsScreen(vm) }
            composable("chat") { ChatScreen(vm) }
            composable("wallet/{id}", arguments = idArg) {
                WalletDetailScreen(
                    vm, it.arguments!!.getLong("id"),
                    onBack = { nav.popBackStack() },
                    onEdit = { id -> nav.navigate("editor/$id") },
                )
            }
            composable("editor/{id}", arguments = idArg) {
                WalletEditorScreen(vm, it.arguments!!.getLong("id"), onDone = { nav.popBackStack() })
            }
        }
    }
}
