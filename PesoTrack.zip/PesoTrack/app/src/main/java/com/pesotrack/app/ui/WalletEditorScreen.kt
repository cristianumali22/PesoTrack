package com.pesotrack.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.pesotrack.app.AppViewModel
import com.pesotrack.app.data.Category
import com.pesotrack.app.data.Fmt
import com.pesotrack.app.data.Money
import com.pesotrack.app.data.Templates
import com.pesotrack.app.data.Wallet
import java.time.LocalDate

private enum class DatePickerTarget { STATEMENT, DUE }

/** Add (walletId = 0) or edit a wallet. Includes the bank / card template picker. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WalletEditorScreen(vm: AppViewModel, walletId: Long, onDone: () -> Unit) {
    val isNew = walletId == 0L
    var name by remember { mutableStateOf("") }
    var templateId by remember { mutableStateOf(Templates.all.first().id) }
    var balanceText by remember { mutableStateOf("") }
    var currency by remember { mutableStateOf("PHP") }
    var rateText by remember { mutableStateOf("") }
    var taxText by remember { mutableStateOf("20") }
    var existing by remember { mutableStateOf<Wallet?>(null) }
    var creditLimitText by remember { mutableStateOf("") }
    var statementEpoch by remember { mutableStateOf<Long?>(null) }
    var dueEpoch by remember { mutableStateOf<Long?>(null) }
    var pickerTarget by remember { mutableStateOf<DatePickerTarget?>(null) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(walletId) {
        if (!isNew) {
            vm.loadWallet(walletId)?.let { w ->
                existing = w
                name = w.name
                templateId = w.templateId
                currency = w.currency
                rateText = w.interestRatePa?.let { Fmt.rate(it) } ?: ""
                taxText = Fmt.rate(w.interestTaxPct)
                creditLimitText = w.creditLimit?.let { Money.format(it, w.currency).removePrefix(Money.symbol(w.currency)) } ?: ""
                statementEpoch = w.nextStatementDate
                dueEpoch = w.nextCreditDueDate
            }
        }
    }

    fun save() {
        val balance = if (isNew) (if (balanceText.isBlank()) 0L else Money.parse(balanceText)) else existing?.balance
        val rate = rateText.trim().takeIf { it.isNotEmpty() }?.toDoubleOrNull()
        val limit = if (creditLimitText.isBlank()) null else Money.parse(creditLimitText)
        if (name.isBlank()) {
            error = "Give the wallet a name"
        } else if (balance == null) {
            error = "Enter a valid balance"
        } else if (rateText.isNotBlank() && rate == null) {
            error = "Interest rate must be a number"
        } else if (creditLimitText.isNotBlank() && limit == null) {
            error = "Credit limit must be a number"
        } else {
            val statementDay = statementEpoch?.let { LocalDate.ofEpochDay(it).dayOfMonth }
            val dueDay = dueEpoch?.let { LocalDate.ofEpochDay(it).dayOfMonth }
            val notified = if (existing?.nextCreditDueDate == dueEpoch) existing?.lastCreditNotifiedDue ?: -1L else -1L
            vm.saveWallet(
                Wallet(
                    id = existing?.id ?: 0,
                    name = name.trim(),
                    templateId = templateId,
                    balance = balance,
                    currency = currency,
                    interestRatePa = rate,
                    interestTaxPct = taxText.toDoubleOrNull() ?: 20.0,
                    lastAccrualDate = existing?.lastAccrualDate ?: LocalDate.now().toEpochDay(),
                    creditLimit = limit,
                    creditStatementDay = statementDay,
                    nextStatementDate = statementEpoch,
                    creditDueDay = dueDay,
                    nextCreditDueDate = dueEpoch,
                    lastCreditNotifiedDue = notified,
                )
            ) { onDone() }
        }
    }

    val tpl = Templates.byId(templateId) ?: Templates.all.first()

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(if (isNew) "Add wallet" else "Edit wallet", onDone)

        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                val shownBalance = if (isNew) Money.parse(balanceText) ?: 0L else existing?.balance ?: 0L
                WalletCardView(tpl, title = name.ifBlank { "Wallet name" }, subtitle = Money.format(shownBalance, currency))
            }
            item {
                OutlinedTextField(
                    value = name, onValueChange = { name = it }, label = { Text("Name (e.g. BDO Savings)") },
                    singleLine = true, modifier = Modifier.fillMaxWidth(),
                )
            }
            if (isNew) {
                item {
                    OutlinedTextField(
                        value = balanceText, onValueChange = { balanceText = it },
                        label = { Text("Current balance") },
                        prefix = { Text(Money.symbol(currency)) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true, modifier = Modifier.fillMaxWidth(),
                    )
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("PHP", "USD", "EUR", "JPY", "SGD").forEach { c ->
                        FilterChip(selected = currency == c, onClick = { currency = c }, label = { Text(c) })
                    }
                }
            }
            if (tpl.category != Category.CREDIT) {
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = rateText, onValueChange = { rateText = it },
                            label = { Text("Interest % p.a.") }, placeholder = { Text("optional") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true, modifier = Modifier.weight(1f),
                        )
                        OutlinedTextField(
                            value = taxText, onValueChange = { taxText = it },
                            label = { Text("Tax on interest %") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true, modifier = Modifier.weight(1f),
                        )
                    }
                }
            }
            if (tpl.category == Category.CREDIT) {
                item {
                    OutlinedTextField(
                        value = creditLimitText, onValueChange = { creditLimitText = it },
                        label = { Text("Credit limit") }, placeholder = { Text("optional") },
                        prefix = { Text(Money.symbol(currency)) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true, modifier = Modifier.fillMaxWidth(),
                    )
                }
                item {
                    OutlinedButton(onClick = { pickerTarget = DatePickerTarget.STATEMENT }, modifier = Modifier.fillMaxWidth()) {
                        Text(statementEpoch?.let { "Statement date: ${Fmt.date(it)}" } ?: "Set statement date (optional)")
                    }
                }
                item {
                    OutlinedButton(onClick = { pickerTarget = DatePickerTarget.DUE }, modifier = Modifier.fillMaxWidth()) {
                        Text(dueEpoch?.let { "Payment due date: ${Fmt.date(it)}" } ?: "Set payment due date (optional)")
                    }
                }
            }
            item { Text("Choose a card design", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 8.dp)) }

            Category.values().forEach { cat ->
                val list = Templates.inCategory(cat)
                item(key = "hdr_${cat.name}") {
                    Text("${cat.label}   ${list.size}", style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                items(list.chunked(2), key = { row -> row.first().id }) { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        row.forEach { t ->
                            Box(Modifier.weight(1f).clickable { templateId = t.id }) {
                                WalletCardView(t, compact = true, selected = t.id == templateId)
                            }
                        }
                        if (row.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }
        }

        error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(horizontal = 16.dp)) }
        Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(onClick = onDone, modifier = Modifier.weight(1f)) { Text("Cancel") }
            Button(onClick = { save() }, modifier = Modifier.weight(1f)) { Text("Save") }
        }
    }

    pickerTarget?.let { target ->
        val current = if (target == DatePickerTarget.STATEMENT) statementEpoch else dueEpoch
        val state = rememberDatePickerState(
            initialSelectedDateMillis = (current ?: LocalDate.now().plusDays(7).toEpochDay()) * 86_400_000L,
        )
        DatePickerDialog(
            onDismissRequest = { pickerTarget = null },
            confirmButton = {
                TextButton(onClick = {
                    state.selectedDateMillis?.let { millis ->
                        val epoch = millis / 86_400_000L
                        if (target == DatePickerTarget.STATEMENT) statementEpoch = epoch else dueEpoch = epoch
                    }
                    pickerTarget = null
                }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { pickerTarget = null }) { Text("Cancel") } },
        ) { DatePicker(state = state) }
    }
}
