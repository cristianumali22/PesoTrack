package com.pesotrack.app.chat

import com.pesotrack.app.data.Money
import com.pesotrack.app.data.Templates
import com.pesotrack.app.data.Wallet

sealed interface ChatAction {
    data class Deposit(val walletId: Long, val amount: Long, val note: String) : ChatAction
    data class Withdraw(val walletId: Long, val amount: Long, val note: String) : ChatAction
    data class Transfer(val fromId: Long, val toId: Long, val amount: Long, val note: String) : ChatAction
}

data class ChatReply(val text: String, val actions: List<ChatAction> = emptyList())

/**
 * Anything that can turn a sentence into wallet actions. The default implementation below is
 * a fully offline, rule-based parser. To use a real on-device LLM later (MediaPipe LLM Inference,
 * Gemini Nano via AICore, llama.cpp...), implement this interface and return the same ChatActions —
 * the confirm-before-saving UI stays the same.
 */
interface ChatEngine {
    suspend fun handle(input: String, wallets: List<Wallet>): ChatReply
}

class RuleBasedChatEngine : ChatEngine {

    private enum class Intent { DEPOSIT, WITHDRAW, TRANSFER }
    private data class Hit(val wallet: Wallet, val range: IntRange)

    private val splitter = Regex("""\s*(?:;|\n|(?<!\d),|,(?!\d)|\band\b|\bthen\b)\s*""")
    private val amountRx = Regex("""(?<![\w.])(?:₱|php\s?|p\s?)?(\d[\d,]*(?:\.\d+)?)\s?([k])?(?![\w])""")
    private val transferRx = Regex("""\b(transfer|move|send)\b""")
    private val depositRx = Regex("""\b(add|deposit|received|receive|got|salary|income|cash ?in|top ?up|topup|credit|earned)\b""")
    private val withdrawRx = Regex("""\b(spent|spend|paid|pay|bought|buy|withdraw|withdrew|record|expense|deduct|cost|charged|cash ?out)\b""")
    private val balanceRx = Regex("""\b(balance|balances|how much|total)\b""")
    private val fillerRx = Regex(
        """\b(add|deposit|received|receive|got|top ?up|topup|credit|earned|spent|spend|paid|pay|bought|buy|withdraw|withdrew|record|expense|deduct|cost|charged|transfer|move|send|cash ?in|cash ?out|to|from|on|for|using|via|in|with|at|my|the|a|an|of|balance|pesos|php|please|this|things|these|following)\b"""
    )

    override suspend fun handle(input: String, wallets: List<Wallet>): ChatReply {
        val text = input.lowercase().trim()
        if (text.isEmpty()) return ChatReply(HELP)
        if (wallets.isEmpty()) {
            return ChatReply("You don't have any wallets yet. Add one from the Wallets tab first, then come back.")
        }

        if (balanceRx.containsMatchIn(text) && intentOf(text) == null) return balanceSummary(text, wallets)

        val clauses = text.split(splitter).map { it.trim() }.filter { it.isNotEmpty() }
        val hitsPerClause = clauses.map { hits(it, wallets) }
        val mentioned = hitsPerClause.flatten().map { it.wallet }.distinctBy { it.id }
        val fallback = mentioned.singleOrNull() ?: wallets.singleOrNull()

        val actions = mutableListOf<ChatAction>()
        val problems = mutableListOf<String>()
        var lastIntent: Intent? = null

        clauses.forEachIndexed { idx, clause ->
            val h = hitsPerClause[idx]
            val masked = mask(clause, h)
            val m = amountRx.find(masked)
            if (m == null) {
                // Ignore small talk; only complain if it looked like a transaction.
                if (h.isNotEmpty() || intentOf(clause) != null) problems += "I didn't find an amount in \"$clause\"."
                return@forEachIndexed
            }
            val amount = parseAmount(m)
            if (amount == null || amount <= 0) {
                problems += "I couldn't read the amount in \"$clause\"."
                return@forEachIndexed
            }
            val intent = intentOf(clause) ?: lastIntent
            if (intent == null) {
                problems += "\"$clause\": say whether it's spent, added, or a transfer (e.g. \"spent 250 on lunch gcash\")."
                return@forEachIndexed
            }
            lastIntent = intent
            val note = noteFrom(masked, m.range)

            when (intent) {
                Intent.TRANSFER -> {
                    if (h.size < 2) {
                        problems += "\"$clause\": a transfer needs two wallets (e.g. \"transfer 1000 from bpi to gcash\")."
                    } else {
                        var (from, to) = h.sortedBy { it.range.first }.take(2).map { it.wallet }
                        val fromIdx = Regex("""\bfrom\b""").find(clause)?.range?.first
                        val firstHitStart = h.minOf { it.range.first }
                        if (fromIdx != null && fromIdx > firstHitStart) { val t = from; from = to; to = t }
                        actions += ChatAction.Transfer(from.id, to.id, amount, note)
                    }
                }
                Intent.DEPOSIT, Intent.WITHDRAW -> {
                    val wallet: Wallet? = when {
                        h.size == 1 -> h[0].wallet
                        h.isEmpty() -> fallback
                        else -> null
                    }
                    if (wallet == null) {
                        problems += if (h.isEmpty())
                            "\"$clause\": which wallet? (${wallets.joinToString(", ") { it.name }})"
                        else
                            "\"$clause\": which one — ${h.joinToString(" or ") { it.wallet.name }}?"
                    } else {
                        actions += if (intent == Intent.DEPOSIT) ChatAction.Deposit(wallet.id, amount, note)
                        else ChatAction.Withdraw(wallet.id, amount, note)
                    }
                }
            }
        }

        if (actions.isEmpty() && problems.isEmpty()) return ChatReply(HELP)

        val sb = StringBuilder()
        if (actions.isNotEmpty()) {
            sb.append("Here's what I'll record:\n")
            actions.forEach { sb.append("• ").append(describe(it, wallets)).append('\n') }
        }
        if (problems.isNotEmpty()) {
            if (actions.isNotEmpty()) sb.append("\nI couldn't handle:\n")
            problems.forEach { sb.append("• ").append(it).append('\n') }
        }
        return ChatReply(sb.toString().trim(), actions)
    }

    // ---- helpers ----

    private fun intentOf(c: String): Intent? = when {
        transferRx.containsMatchIn(c) -> Intent.TRANSFER
        depositRx.containsMatchIn(c) -> Intent.DEPOSIT
        withdrawRx.containsMatchIn(c) -> Intent.WITHDRAW
        else -> null
    }

    private fun aliases(w: Wallet): Set<String> {
        val name = w.name.lowercase().trim()
        val tpl = Templates.byId(w.templateId)?.label?.lowercase()
        val first = name.substringBefore(' ')
        return setOfNotNull(name, tpl, first.takeIf { it.length >= 3 }).filter { it.isNotBlank() }.toSet()
    }

    private fun hits(clause: String, wallets: List<Wallet>): List<Hit> {
        val raw = wallets.mapNotNull { w ->
            aliases(w).mapNotNull { a ->
                Regex("""\b${Regex.escape(a)}\b""").find(clause)?.let { Hit(w, it.range) }
            }.maxByOrNull { it.range.last - it.range.first }
        }
        fun len(h: Hit) = h.range.last - h.range.first
        // Drop matches that sit inside a longer match ("bdo" inside "bdo gold").
        return raw.filter { h ->
            raw.none { o ->
                o !== h && o.range.first <= h.range.first && o.range.last >= h.range.last && len(o) > len(h)
            }
        }
    }

    private fun mask(clause: String, hits: List<Hit>): String {
        val sb = StringBuilder(clause)
        hits.forEach { h -> for (i in h.range) sb.setCharAt(i, ' ') }
        return sb.toString()
    }

    private fun parseAmount(m: MatchResult): Long? {
        val n = m.groupValues[1].replace(",", "").toBigDecimalOrNull() ?: return null
        val v = if (m.groupValues[2].isNotEmpty()) n.multiply(java.math.BigDecimal(1000)) else n
        return Money.fromDecimal(v)
    }

    private fun noteFrom(masked: String, amountRange: IntRange): String {
        val sb = StringBuilder(masked)
        for (i in amountRange) sb.setCharAt(i, ' ')
        val cleaned = fillerRx.replace(sb.toString(), " ").replace(Regex("""[^\p{L}\p{N} ]"""), " ")
            .replace(Regex("""\s+"""), " ").trim()
        return if (cleaned.isEmpty()) "Via assistant" else cleaned.replaceFirstChar { it.uppercase() }
    }

    private fun describe(a: ChatAction, wallets: List<Wallet>): String {
        fun w(id: Long) = wallets.first { it.id == id }
        return when (a) {
            is ChatAction.Deposit -> "Add ${Money.format(a.amount, w(a.walletId).currency)} to ${w(a.walletId).name}" +
                if (a.note != "Via assistant") " (${a.note})" else ""
            is ChatAction.Withdraw -> "Spend ${Money.format(a.amount, w(a.walletId).currency)} from ${w(a.walletId).name}" +
                if (a.note != "Via assistant") " (${a.note})" else ""
            is ChatAction.Transfer -> "Move ${Money.format(a.amount, w(a.fromId).currency)} from ${w(a.fromId).name} to ${w(a.toId).name}"
        }
    }

    private fun balanceSummary(text: String, wallets: List<Wallet>): ChatReply {
        val mentioned = hits(text, wallets).map { it.wallet }
        val list = mentioned.ifEmpty { wallets }
        val lines = list.joinToString("\n") { "• ${it.name}: ${Money.format(it.balance, it.currency)}" }
        val total = if (mentioned.isEmpty()) {
            wallets.groupBy { it.currency }.entries
                .joinToString(" + ") { (c, l) -> Money.format(l.sumOf { it.balance }, c) }
        } else null
        return ChatReply(lines + (total?.let { "\n\nTotal: $it" } ?: ""))
    }

    companion object {
        const val HELP = "I work offline and can record things for you. Try:\n" +
            "• \"Spent 250 on lunch from GCash\"\n" +
            "• \"Add 5000 to BDO, 2000 to Maya\"\n" +
            "• \"Transfer 1000 from BPI to GCash\"\n" +
            "• \"What's my balance?\""
    }
}
