package com.pesotrack.app.notify

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.pesotrack.app.MainActivity
import com.pesotrack.app.R
import com.pesotrack.app.data.AppDatabase
import com.pesotrack.app.data.Bill
import com.pesotrack.app.data.Fmt
import com.pesotrack.app.data.Installment
import com.pesotrack.app.data.Money
import com.pesotrack.app.data.Repository
import com.pesotrack.app.data.Wallet
import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime
import java.util.concurrent.TimeUnit

/** How many days before the due date we start reminding. */
const val REMINDER_DAYS = 5

object Notifications {
    const val CHANNEL_ID = "installment_due"

    fun ensureChannel(ctx: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            val ch = NotificationChannel(CHANNEL_ID, "Installment reminders", NotificationManager.IMPORTANCE_HIGH)
            ch.description = "Reminds you $REMINDER_DAYS days before an installment is due"
            nm.createNotificationChannel(ch)
        }
    }

    @SuppressLint("MissingPermission")
    fun notifyDue(ctx: Context, i: Installment, daysLeft: Int) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        val whenText = when (daysLeft) {
            0 -> "today"
            1 -> "tomorrow"
            else -> "in $daysLeft days"
        }
        val open = PendingIntent.getActivity(
            ctx, i.id.toInt(),
            Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val n = NotificationCompat.Builder(ctx, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_peso)
            .setContentTitle("${i.name} is due $whenText")
            .setContentText("${Money.format(i.amount)} · ${i.place} · ${Fmt.date(i.dueDate)}")
            .setContentIntent(open)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        NotificationManagerCompat.from(ctx).notify(1000 + i.id.toInt(), n)
    }

    /** Separate from installments: a credit card's own recurring statement due date. */
    @SuppressLint("MissingPermission")
    fun notifyCardDue(ctx: Context, wallet: Wallet, daysLeft: Int, spent: Long) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        val whenText = when (daysLeft) {
            0 -> "today"
            1 -> "tomorrow"
            else -> "in $daysLeft days"
        }
        val open = PendingIntent.getActivity(
            ctx, 5000 + wallet.id.toInt(),
            Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val n = NotificationCompat.Builder(ctx, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_peso)
            .setContentTitle("${wallet.name} payment due $whenText")
            .setContentText("Total spent: ${Money.format(spent, wallet.currency)}")
            .setContentIntent(open)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        NotificationManagerCompat.from(ctx).notify(2000 + wallet.id.toInt(), n)
    }

    /** Recurring bill reminder — separate channel content from installments/credit cards. */
    @SuppressLint("MissingPermission")
    fun notifyBillDue(ctx: Context, b: Bill, daysLeft: Int, walletName: String?) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        val whenText = when (daysLeft) {
            0 -> "today"
            1 -> "tomorrow"
            else -> "in $daysLeft days"
        }
        val open = PendingIntent.getActivity(
            ctx, 6000 + b.id.toInt(),
            Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val n = NotificationCompat.Builder(ctx, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_peso)
            .setContentTitle("${b.name} is due $whenText")
            .setContentText(Money.format(b.amount) + (walletName?.let { " · $it" } ?: "") + " · ${Fmt.date(b.dueDate)}")
            .setContentIntent(open)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        NotificationManagerCompat.from(ctx).notify(3000 + b.id.toInt(), n)
    }
}

/** Runs daily; notifies once per due date when it is [REMINDER_DAYS] days (or fewer) away. */
class DueReminderWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val db = AppDatabase.get(applicationContext)
        val dao = db.installmentDao()
        val billDao = db.billDao()
        val walletDao = db.walletDao()
        val repo = Repository(db)
        val today = LocalDate.now().toEpochDay()

        for (i in dao.getAll()) {
            if (i.remainingPayments <= 0) continue
            val left = (i.dueDate - today).toInt()
            // Daily reminder on each of the 5 days leading up to the due date (5,4,3,2,1),
            // once per calendar day rather than once per due date.
            if (left in 1..REMINDER_DAYS && i.lastNotifiedDay != today) {
                Notifications.notifyDue(applicationContext, i, left)
                dao.update(i.copy(lastNotifiedDay = today))
            }
        }

        // Credit card statement due dates: separate from installments, and self-rolling monthly.
        for (w in walletDao.getAll()) {
            val due = w.nextCreditDueDate ?: continue
            val day = w.creditDueDay ?: continue
            val left = (due - today).toInt()
            if (left < 0) {
                walletDao.setCreditDue(w.id, Repository.nextDueDate(due, day), -1)
            } else if (left in 0..REMINDER_DAYS && w.lastCreditNotifiedDue != due) {
                val spent = repo.cardSpentSync(w.id)
                Notifications.notifyCardDue(applicationContext, w, left, spent)
                walletDao.setCreditDue(w.id, due, due)
            }
        }

        // Recurring bills: same daily 5,4,3,2,1 pattern as installments.
        for (b in billDao.getAll()) {
            val left = (b.dueDate - today).toInt()
            if (left in 1..REMINDER_DAYS && b.lastNotifiedDay != today) {
                val walletName = b.walletId?.let { walletDao.get(it)?.name }
                Notifications.notifyBillDue(applicationContext, b, left, walletName)
                billDao.update(b.copy(lastNotifiedDay = today))
            }
        }
        return Result.success()
    }
}

object Reminders {
    private const val UNIQUE = "installment_due_check"

    /** Schedules the daily 9:00 AM check (kept across restarts) and runs one check now. */
    fun schedule(ctx: Context) {
        val now = LocalDateTime.now()
        var next = now.toLocalDate().atTime(9, 0)
        if (!next.isAfter(now)) next = next.plusDays(1)
        val delay = Duration.between(now, next).toMillis()
        val req = PeriodicWorkRequestBuilder<DueReminderWorker>(1, TimeUnit.DAYS)
            .setInitialDelay(delay, TimeUnit.MILLISECONDS)
            .build()
        WorkManager.getInstance(ctx).enqueueUniquePeriodicWork(UNIQUE, ExistingPeriodicWorkPolicy.KEEP, req)
        runNow(ctx)
    }

    fun runNow(ctx: Context) {
        WorkManager.getInstance(ctx).enqueue(OneTimeWorkRequestBuilder<DueReminderWorker>().build())
    }
}
