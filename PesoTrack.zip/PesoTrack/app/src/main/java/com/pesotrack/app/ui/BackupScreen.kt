package com.pesotrack.app.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.pesotrack.app.AppViewModel
import com.pesotrack.app.data.Fmt
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.ZoneId

@Composable
fun BackupScreen(vm: AppViewModel) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var status by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var confirmImportUri by remember { mutableStateOf<Uri?>(null) }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        busy = true
        vm.exportBackup { result ->
            result.onSuccess { json ->
                runCatching {
                    context.contentResolver.openOutputStream(uri)?.use { it.write(json.toByteArray()) }
                }.onSuccess { status = "Backup saved ✓" }
                    .onFailure { status = "Couldn't write the file: ${it.message}" }
            }.onFailure { status = "Couldn't read your data: ${it.message}" }
            busy = false
        }
    }

    val pickLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) confirmImportUri = uri
    }

    fun doImport(uri: Uri) {
        busy = true
        scope.launch {
            val json = runCatching {
                context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                    ?: error("File is empty")
            }
            json.onSuccess { text ->
                vm.importBackup(text) { result ->
                    status = result.fold(
                        onSuccess = { "Restored ✓ Your wallets are back." },
                        onFailure = { "Couldn't restore: is this a PesoTrack backup file? (${it.message})" },
                    )
                    busy = false
                }
            }.onFailure {
                status = "Couldn't read the file: ${it.message}"
                busy = false
            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Backup & Restore", null)
        Column(
            Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.primaryContainer) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Do this before installing an update", fontWeight = FontWeight.SemiBold)
                    Text(
                        "An app update can occasionally require resetting the database. " +
                            "Export a backup first, install the update, then restore it — nothing is lost.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
            }

            Button(
                onClick = {
                    val stamp = Instant.now().atZone(ZoneId.systemDefault())
                    exportLauncher.launch("pesotrack-backup-${Fmt.date(stamp.toLocalDate().toEpochDay())}.json".replace(" ", "").replace(",", ""))
                },
                modifier = Modifier.fillMaxWidth(),
                enabled = !busy,
            ) {
                Icon(Icons.Filled.CloudUpload, contentDescription = null)
                Text("  Export backup")
            }

            OutlinedButton(
                onClick = { pickLauncher.launch(arrayOf("application/json")) },
                modifier = Modifier.fillMaxWidth(),
                enabled = !busy,
            ) {
                Icon(Icons.Filled.CloudDownload, contentDescription = null)
                Text("  Restore from backup")
            }

            if (busy) CircularProgressIndicator(modifier = Modifier.padding(top = 8.dp))
            status?.let { Text(it, style = MaterialTheme.typography.bodyMedium) }
        }
    }

    confirmImportUri?.let { uri ->
        AlertDialog(
            onDismissRequest = { confirmImportUri = null },
            title = { Text("Restore this backup?") },
            text = { Text("This replaces everything currently in the app with what's in the backup file. This can't be undone.") },
            confirmButton = {
                TextButton(onClick = { confirmImportUri = null; doImport(uri) }) { Text("Restore") }
            },
            dismissButton = { TextButton(onClick = { confirmImportUri = null }) { Text("Cancel") } },
        )
    }
}
