package com.pesotrack.app.data

import androidx.room.withTransaction
import java.time.LocalDate
import java.time.YearMonth
import kotlin.math.roundToLong

class Repository(private val db: AppDatabase) {
    private val wallets = db.walletDao()
    private val txs = db.txDao()
    private val installmentsDao = db.installmentDao()

    val allWallets = wallets.observeAll()
    val recent = txs.observeRecent(30)
    val installments = installmentsDao.observeAll()

    fun wallet(id: Long) = wallets.observe(id)
    fun walletTx(id: Long) = txs.observeForWallet(id)
    fun cardSpent(walletId: Long) = txs.observeCardSpent(walletId)
    suspend fun getWallet(id: Long) = wallets.get(id)

    // ---- wallets ----

    suspend fun addWallet(w: Wallet): Long = db.withTransaction {
        val id = wallets.insert(w)
        if (w.balance != 0L) {
            txs.insert(Tx(walletId = id, type = TxType.DEPOSIT, amount = w.balance, note = "Opening balance"))
        }
        id
    }

    suspend fun updateWallet(w: Wallet) {
        val old = wallets.get(w.id)
        // If the interest rate changed, start accruing from today instead of back-dating.
        val fixed = if (old != null && old.interestRatePa != w.interestRatePa)
            w.copy(lastAccrualDate = LocalDate.now().toEpochDay()) else w
        wallets.update(fixed)
    }

    suspend fun deleteWallet(w: Wallet) = wallets.delete(w)

    // ---- transactions ----

    /** Returns an error message, or null on success. */
    suspend fun record(walletId: Long, type: TxType, amount: Long, note: String = ""): String? =
        db.withTransaction {
            val w = wallets.get(walletId) ?: return@withTransaction "Wallet not found"
            if (amount <= 0) return@withTransaction "Enter an amount greater than 0"
            if (!type.credit && w.balance < amount) return@withTransaction "Not enough balance in ${w.name}"
            txs.insert(Tx(walletId = walletId, type = type, amount = amount, note = note))
            wallets.adjust(walletId, if (type.credit) amount else -amount)
            null
        }

    suspend fun transfer(fromId: Long, toId: Long, amount: Long, note: String = ""): String? =
        db.withTransaction {
            if (fromId == toId) return@withTransaction "Pick two different wallets"
            val from = wallets.get(fromId) ?: return@withTransaction "Source wallet not found"
            val to = wallets.get(toId) ?: return@withTransaction "Destination wallet not found"
            if (amount <= 0) return@withTransaction "Enter an amount greater than 0"
            if (from.currency != to.currency) return@withTransaction "Wallets use different currencies"
            if (from.balance < amount) return@withTransaction "Not enough balance in ${from.name}"
            txs.insert(Tx(walletId = fromId, type = TxType.TRANSFER_OUT, amount = amount,
                note = note.ifBlank { "To ${to.name}" }, counterpartWalletId = toId))
            txs.insert(Tx(walletId = toId, type = TxType.TRANSFER_IN, amount = amount,
                note = note.ifBlank { "From ${from.name}" }, counterpartWalletId = fromId))
            wallets.adjust(fromId, -amount)
            wallets.adjust(toId, amount)
            null
        }

    /** Credits simple daily interest (net of tax) for every day since the last accrual. */
    suspend fun accrueAll() {
        val today = LocalDate.now().toEpochDay()
        for (w in wallets.getAll()) {
            val rate = w.interestRatePa ?: continue
            val days = today - w.lastAccrualDate
            if (days < 1) continue
            db.withTransaction {
                val gross = w.balance * rate / 100.0 / 365.0 * days
                val net = (gross * (1 - w.interestTaxPct / 100.0)).roundToLong()
                if (net > 0) {
                    txs.insert(Tx(walletId = w.id, type = TxType.INTEREST, amount = net,
                        note = "Interest · $days day(s) @ ${Fmt.rate(rate)}% p.a."))
                    wallets.adjust(w.id, net)
                }
                wallets.setAccrualDate(w.id, today)
            }
        }
    }

    // ---- installments ----

    suspend fun addInstallment(i: Installment) = installmentsDao.insert(i)
    suspend fun deleteInstallment(i: Installment) = installmentsDao.delete(i)

    /** Marks one payment as paid, optionally deducting it from a wallet, and rolls the due date forward. */
    suspend fun payInstallment(i: Installment, walletId: Long?): String? = db.withTransaction {
        if (i.remainingPayments <= 0) return@withTransaction "Already fully paid"
        if (walletId != null) {
            val err = record(walletId, TxType.INSTALLMENT, i.amount, i.name)
            if (err != null) return@withTransaction err
        }
        installmentsDao.update(
            i.copy(remainingPayments = i.remainingPayments - 1, dueDate = nextDueDate(i.dueDate, i.dueDay))
        )
        null
    }

    companion object {
        fun nextDueDate(dueEpochDay: Long, dueDay: Int): Long {
            val ym = YearMonth.from(LocalDate.ofEpochDay(dueEpochDay)).plusMonths(1)
            return ym.atDay(minOf(dueDay, ym.lengthOfMonth())).toEpochDay()
        }
    }
}
