package com.pesotrack.app.data

import androidx.room.withTransaction
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import java.time.LocalDate
import java.time.YearMonth
import kotlin.math.roundToLong

/** Transaction types that count as "spending" on a credit card. */
private val CARD_SPEND_TYPES = setOf(TxType.WITHDRAW, TxType.INSTALLMENT, TxType.BILL)

class Repository(private val db: AppDatabase) {
    private val wallets = db.walletDao()
    private val txs = db.txDao()
    private val installmentsDao = db.installmentDao()
    private val billsDao = db.billDao()

    val allWallets = wallets.observeAll()
    val recent = txs.observeRecent(30)
    val installments = installmentsDao.observeAll()
    val bills = billsDao.observeAll()

    fun wallet(id: Long) = wallets.observe(id)
    fun walletTx(id: Long) = txs.observeForWallet(id)

    /** Reactive running total spent on a credit card since its last "mark as paid". */
    fun cardSpent(walletId: Long): Flow<Long> =
        combine(wallets.observe(walletId), txs.observeForWallet(walletId)) { w, list ->
            val since = w?.spendCycleStart ?: 0L
            list.filter { it.type in CARD_SPEND_TYPES && it.timestamp >= since }.sumOf { it.amount }
        }

    /** One-shot version of [cardSpent], for use outside Compose (e.g. the reminder worker). */
    suspend fun cardSpentSync(walletId: Long): Long {
        val w = wallets.get(walletId) ?: return 0L
        return txs.getForWallet(walletId)
            .filter { it.type in CARD_SPEND_TYPES && it.timestamp >= w.spendCycleStart }
            .sumOf { it.amount }
    }

    suspend fun getWallet(id: Long) = wallets.get(id)

    // ---- wallets ----

    suspend fun addWallet(w: Wallet): Long = db.withTransaction {
        val id = wallets.insert(w)
        if (w.balance != 0L) {
            txs.insert(Tx(walletId = id, type = TxType.DEPOSIT, amount = w.balance, note = "Opening balance"))
        }
        id
    }

    suspend fun updateWallet(w: Wallet) {
        val old = wallets.get(w.id)
        // If the interest rate changed, start accruing from today instead of back-dating.
        val fixed = if (old != null && old.interestRatePa != w.interestRatePa)
            w.copy(lastAccrualDate = LocalDate.now().toEpochDay()) else w
        wallets.update(fixed)
    }

    suspend fun deleteWallet(w: Wallet) = wallets.delete(w)

    // ---- transactions ----

    /** Returns an error message, or null on success. */
    suspend fun record(walletId: Long, type: TxType, amount: Long, note: String = ""): String? =
        db.withTransaction {
            val w = wallets.get(walletId) ?: return@withTransaction "Wallet not found"
            if (amount <= 0) return@withTransaction "Enter an amount greater than 0"
            if (!type.credit && w.balance < amount) return@withTransaction "Not enough balance in ${w.name}"
            txs.insert(Tx(walletId = walletId, type = type, amount = amount, note = note))
            wallets.adjust(walletId, if (type.credit) amount else -amount)
            null
        }

    suspend fun transfer(fromId: Long, toId: Long, amount: Long, note: String = ""): String? =
        db.withTransaction {
            if (fromId == toId) return@withTransaction "Pick two different wallets"
            val from = wallets.get(fromId) ?: return@withTransaction "Source wallet not found"
            val to = wallets.get(toId) ?: return@withTransaction "Destination wallet not found"
            if (amount <= 0) return@withTransaction "Enter an amount greater than 0"
            if (from.currency != to.currency) return@withTransaction "Wallets use different currencies"
            if (from.balance < amount) return@withTransaction "Not enough balance in ${from.name}"
            txs.insert(Tx(walletId = fromId, type = TxType.TRANSFER_OUT, amount = amount,
                note = note.ifBlank { "To ${to.name}" }, counterpartWalletId = toId))
            txs.insert(Tx(walletId = toId, type = TxType.TRANSFER_IN, amount = amount,
                note = note.ifBlank { "From ${from.name}" }, counterpartWalletId = fromId))
            wallets.adjust(fromId, -amount)
            wallets.adjust(toId, amount)
            null
        }

    /** Credits simple daily interest (net of tax) for every day since the last accrual. */
    suspend fun accrueAll() {
        val today = LocalDate.now().toEpochDay()
        for (w in wallets.getAll()) {
            val rate = w.interestRatePa ?: continue
            val days = today - w.lastAccrualDate
            if (days < 1) continue
            db.withTransaction {
                val gross = w.balance * rate / 100.0 / 365.0 * days
                val net = (gross * (1 - w.interestTaxPct / 100.0)).roundToLong()
                if (net > 0) {
                    txs.insert(Tx(walletId = w.id, type = TxType.INTEREST, amount = net,
                        note = "Interest · $days day(s) @ ${Fmt.rate(rate)}% p.a."))
                    wallets.adjust(w.id, net)
                }
                wallets.setAccrualDate(w.id, today)
            }
        }
    }

    // ---- installments ----

    suspend fun addInstallment(i: Installment) = installmentsDao.insert(i)
    suspend fun deleteInstallment(i: Installment) = installmentsDao.delete(i)

    /** Marks one payment as paid, optionally deducting it from a wallet, and rolls the due date forward. */
    suspend fun payInstallment(i: Installment, walletId: Long?): String? = db.withTransaction {
        if (i.remainingPayments <= 0) return@withTransaction "Already fully paid"
        if (walletId != null) {
            val err = record(walletId, TxType.INSTALLMENT, i.amount, i.name)
            if (err != null) return@withTransaction err
        }
        installmentsDao.update(
            i.copy(remainingPayments = i.remainingPayments - 1, dueDate = nextDueDate(i.dueDate, i.dueDay))
        )
        null
    }

    // ---- recurring bills ----

    suspend fun addBill(b: Bill) = billsDao.insert(b)
    suspend fun deleteBill(b: Bill) = billsDao.delete(b)

    /** Marks the current due date as paid, optionally deducting it from a wallet, and rolls the due date forward. */
    suspend fun payBill(b: Bill, walletId: Long?): String? = db.withTransaction {
        if (walletId != null) {
            val err = record(walletId, TxType.BILL, b.amount, b.name)
            if (err != null) return@withTransaction err
        }
        billsDao.update(b.copy(dueDate = nextDueDate(b.dueDate, b.dueDay)))
        null
    }

    // ---- credit cards ----

    /**
     * Marks the card's current running total as paid: records the payment (if you choose a
     * wallet to pay from), starts a fresh spend total for the new cycle, rolls the due date
     * forward, and remembers what/when so you have a clear confirmation it's done.
     */
    suspend fun markCardPaid(cardId: Long, payFromWalletId: Long?): String? = db.withTransaction {
        val card = wallets.get(cardId) ?: return@withTransaction "Card not found"
        val amount = cardSpentSync(cardId)
        if (amount <= 0) return@withTransaction "Nothing to mark as paid yet"
        if (payFromWalletId != null) {
            val err = record(payFromWalletId, TxType.CARD_PAYMENT, amount, "${card.name} payment")
            if (err != null) return@withTransaction err
        }
        val today = LocalDate.now().toEpochDay()
        val rolledDue = card.creditDueDay?.let { day ->
            nextDueDate(card.nextCreditDueDate ?: today, day)
        } ?: card.nextCreditDueDate
        wallets.update(
            card.copy(
                spendCycleStart = System.currentTimeMillis(),
                lastCardPaymentAmount = amount,
                lastCardPaymentDate = today,
                nextCreditDueDate = rolledDue,
                lastCreditNotifiedDue = -1,
            )
        )
        null
    }

    // ---- backup / restore ----

    suspend fun exportBackup(): String {
        val data = BackupData(wallets.getAll(), txs.getAll(), installmentsDao.getAll(), billsDao.getAll())
        return Backup.toJson(data)
    }

    /** Wipes current data and replaces it with the backup's contents. */
    suspend fun importBackup(json: String) = db.withTransaction {
        val data = Backup.fromJson(json)
        txs.deleteAll()
        installmentsDao.deleteAll()
        billsDao.deleteAll()
        wallets.deleteAll()
        data.wallets.forEach { wallets.insert(it) }
        data.transactions.forEach { txs.insert(it) }
        data.installments.forEach { installmentsDao.insert(it) }
        data.bills.forEach { billsDao.insert(it) }
        Unit
    }

    companion object {
        fun nextDueDate(dueEpochDay: Long, dueDay: Int): Long {
            val ym = YearMonth.from(LocalDate.ofEpochDay(dueEpochDay)).plusMonths(1)
            return ym.atDay(minOf(dueDay, ym.lengthOfMonth())).toEpochDay()
        }
    }
}
