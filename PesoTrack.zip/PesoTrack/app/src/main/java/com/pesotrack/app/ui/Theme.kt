package com.pesotrack.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Sage = Color(0xFF5E9A4C)
val Cream = Color(0xFFF7F6F1)
val Positive = Color(0xFF2E7D32)
val Negative = Color(0xFFC62828)

private val Colors = lightColorScheme(
    primary = Sage,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDCEBD5),
    onPrimaryContainer = Color(0xFF1B3A12),
    secondaryContainer = Color(0xFFE6EDE0),
    background = Cream,
    surface = Color.White,
    surfaceVariant = Color(0xFFEFEEE8),
)

@Composable
fun PesoTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Colors, content = content)
}
