package com.pesotrack.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.pesotrack.app.data.TxType
import com.pesotrack.app.ui.PesoTheme
import com.pesotrack.app.ui.TransactionForm

/** Small popup launched from the home-screen widget: pick wallet, amount, save. */
class QuickAddActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val initial = when (intent.getStringExtra(EXTRA_TYPE)) {
            "DEPOSIT" -> TxType.DEPOSIT
            "TRANSFER" -> TxType.TRANSFER_OUT
            else -> TxType.WITHDRAW
        }

        setContent {
            PesoTheme {
                val wallets by vm.wallets.collectAsStateWithLifecycle()
                Box(
                    Modifier.fillMaxSize().background(Color(0x99000000))
                        .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { finish() },
                    contentAlignment = Alignment.Center,
                ) {
                    Surface(
                        shape = RoundedCornerShape(24.dp),
                        modifier = Modifier.padding(24.dp)
                            // swallow taps so touching the card doesn't close the popup
                            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { },
                    ) {
                        val list = wallets
                        when {
                            list == null -> Text("Loading…", modifier = Modifier.padding(24.dp))
                            list.isEmpty() -> Column(Modifier.padding(24.dp)) {
                                Text("Add a wallet in the app first.")
                                Button(onClick = {
                                    startActivity(packageManager.getLaunchIntentForPackage(packageName))
                                    finish()
                                }) { Text("Open PesoTrack") }
                            }
                            else -> TransactionForm(
                                wallets = list, initialType = initial, initialWalletId = null,
                                onSubmit = vm::submit, onDismiss = { finish() },
                            )
                        }
                    }
                }
            }
        }
    }

    companion object {
        const val EXTRA_TYPE = "type"
    }
}
