package com.pesotrack.app.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface WalletDao {
    @Query("SELECT * FROM wallets ORDER BY id") fun observeAll(): Flow<List<Wallet>>
    @Query("SELECT * FROM wallets ORDER BY id") suspend fun getAll(): List<Wallet>
    @Query("SELECT * FROM wallets WHERE id = :id") suspend fun get(id: Long): Wallet?
    @Query("SELECT * FROM wallets WHERE id = :id") fun observe(id: Long): Flow<Wallet?>
    @Insert suspend fun insert(w: Wallet): Long
    @Update suspend fun update(w: Wallet)
    @Delete suspend fun delete(w: Wallet)
    @Query("UPDATE wallets SET balance = balance + :delta WHERE id = :id") suspend fun adjust(id: Long, delta: Long)
    @Query("UPDATE wallets SET lastAccrualDate = :day WHERE id = :id") suspend fun setAccrualDate(id: Long, day: Long)
}

@Dao
interface TxDao {
    @Insert suspend fun insert(t: Tx): Long
    @Query("SELECT * FROM transactions ORDER BY timestamp DESC LIMIT :limit") fun observeRecent(limit: Int): Flow<List<Tx>>
    @Query("SELECT * FROM transactions WHERE walletId = :walletId ORDER BY timestamp DESC") fun observeForWallet(walletId: Long): Flow<List<Tx>>
}

@Dao
interface InstallmentDao {
    @Query("SELECT * FROM installments ORDER BY dueDate") fun observeAll(): Flow<List<Installment>>
    @Query("SELECT * FROM installments") suspend fun getAll(): List<Installment>
    @Insert suspend fun insert(i: Installment): Long
    @Update suspend fun update(i: Installment)
    @Delete suspend fun delete(i: Installment)
}
