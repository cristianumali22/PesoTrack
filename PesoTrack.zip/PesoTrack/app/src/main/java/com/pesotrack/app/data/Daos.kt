package com.pesotrack.app.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface WalletDao {
    @Query("SELECT * FROM wallets ORDER BY id") fun observeAll(): Flow<List<Wallet>>
    @Query("SELECT * FROM wallets ORDER BY id") suspend fun getAll(): List<Wallet>
    @Query("SELECT * FROM wallets WHERE id = :id") suspend fun get(id: Long): Wallet?
    @Query("SELECT * FROM wallets WHERE id = :id") fun observe(id: Long): Flow<Wallet?>
    @Insert suspend fun insert(w: Wallet): Long
    @Update suspend fun update(w: Wallet)
    @Delete suspend fun delete(w: Wallet)
    @Query("UPDATE wallets SET balance = balance + :delta WHERE id = :id") suspend fun adjust(id: Long, delta: Long)
    @Query("UPDATE wallets SET lastAccrualDate = :day WHERE id = :id") suspend fun setAccrualDate(id: Long, day: Long)
    @Query("UPDATE wallets SET nextCreditDueDate = :date, lastCreditNotifiedDue = :notified WHERE id = :id")
    suspend fun setCreditDue(id: Long, date: Long?, notified: Long)
    @Query("DELETE FROM wallets") suspend fun deleteAll()
}

@Dao
interface TxDao {
    @Insert suspend fun insert(t: Tx): Long
    @Query("SELECT * FROM transactions ORDER BY timestamp DESC LIMIT :limit") fun observeRecent(limit: Int): Flow<List<Tx>>
    @Query("SELECT * FROM transactions WHERE walletId = :walletId ORDER BY timestamp DESC") fun observeForWallet(walletId: Long): Flow<List<Tx>>
    @Query("SELECT * FROM transactions WHERE walletId = :walletId ORDER BY timestamp DESC") suspend fun getForWallet(walletId: Long): List<Tx>
    @Query("SELECT * FROM transactions ORDER BY id") suspend fun getAll(): List<Tx>
    @Query("DELETE FROM transactions") suspend fun deleteAll()
}

@Dao
interface InstallmentDao {
    @Query("SELECT * FROM installments ORDER BY dueDate") fun observeAll(): Flow<List<Installment>>
    @Query("SELECT * FROM installments") suspend fun getAll(): List<Installment>
    @Insert suspend fun insert(i: Installment): Long
    @Update suspend fun update(i: Installment)
    @Delete suspend fun delete(i: Installment)
    @Query("DELETE FROM installments") suspend fun deleteAll()
}

@Dao
interface BillDao {
    @Query("SELECT * FROM bills ORDER BY dueDate") fun observeAll(): Flow<List<Bill>>
    @Query("SELECT * FROM bills") suspend fun getAll(): List<Bill>
    @Insert suspend fun insert(b: Bill): Long
    @Update suspend fun update(b: Bill)
    @Delete suspend fun delete(b: Bill)
    @Query("DELETE FROM bills") suspend fun deleteAll()
}
