package com.pesotrack.app.data

import java.math.BigDecimal
import java.math.RoundingMode
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.abs

object Money {
    fun fromDecimal(value: BigDecimal): Long =
        value.movePointRight(2).setScale(0, RoundingMode.HALF_UP).toLong()

    /** Parses "1,250.50" into centavos. Returns null if not a number. */
    fun parse(text: String): Long? {
        val clean = text.replace(",", "").replace("₱", "").trim()
        if (clean.isEmpty()) return null
        return clean.toBigDecimalOrNull()?.let { fromDecimal(it) }
    }

    fun symbol(currency: String) = when (currency) {
        "PHP" -> "₱"
        "USD" -> "$"
        "EUR" -> "€"
        "JPY" -> "¥"
        "SGD" -> "S$"
        else -> "$currency "
    }

    fun format(centavos: Long, currency: String = "PHP"): String {
        val a = abs(centavos)
        val body = String.format(Locale.US, "%,d.%02d", a / 100, a % 100)
        return (if (centavos < 0) "-" else "") + symbol(currency) + body
    }
}

object Fmt {
    private val dateFmt = DateTimeFormatter.ofPattern("MMM d, yyyy", Locale.US)
    private val dateTimeFmt = DateTimeFormatter.ofPattern("MMM d, h:mm a", Locale.US)

    fun date(epochDay: Long): String = LocalDate.ofEpochDay(epochDay).format(dateFmt)
    fun dateTime(millis: Long): String =
        Instant.ofEpochMilli(millis).atZone(ZoneId.systemDefault()).format(dateTimeFmt)

    fun rate(value: Double): String =
        if (value % 1.0 == 0.0) value.toLong().toString() else value.toString()
}
