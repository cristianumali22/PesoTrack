package com.pesotrack.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.pesotrack.app.AppViewModel
import com.pesotrack.app.data.Money
import com.pesotrack.app.data.Templates
import com.pesotrack.app.data.TxType

@Composable
fun HomeScreen(vm: AppViewModel, onOpenWallet: (Long) -> Unit, onAddWallet: () -> Unit) {
    val wallets = vm.wallets.collectAsStateWithLifecycle().value
    val recent by vm.recent.collectAsStateWithLifecycle()
    var showTx by remember { mutableStateOf(false) }

    if (wallets == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        return
    }

    val totals = wallets.groupBy { it.currency }.entries
        .joinToString(" + ") { (c, l) -> Money.format(l.sumOf { it.balance }, c) }
        .ifEmpty { Money.format(0) }
    val byId = wallets.associateBy { it.id }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                Column {
                    Text("Total balance", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(totals, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = { showTx = true }, enabled = wallets.isNotEmpty()) {
                        Icon(Icons.Filled.SwapHoriz, contentDescription = null)
                        Spacer(Modifier.padding(start = 6.dp))
                        Text("Record transaction")
                    }
                }
            }
            if (wallets.isEmpty()) {
                item {
                    Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surface) {
                        Text(
                            "No wallets yet. Tap “Add wallet” to add a bank, e-wallet, digital bank or credit card and its current balance.",
                            modifier = Modifier.padding(16.dp),
                        )
                    }
                }
            }
            if (wallets.isNotEmpty()) {
                item {
                    WalletStack(wallets = wallets, onOpen = onOpenWallet)
                }
            }
            if (recent.isNotEmpty()) {
                item {
                    Text("Recent activity", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 8.dp))
                }
                items(recent.take(10), key = { "tx_${it.id}" }) { tx ->
                    TxRow(tx, byId[tx.walletId]?.name, byId[tx.walletId]?.currency ?: "PHP")
                }
            }
        }
        ExtendedFloatingActionButton(
            onClick = onAddWallet,
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp),
            icon = { Icon(Icons.Filled.Add, contentDescription = null) },
            text = { Text("Add wallet") },
        )
    }

    if (showTx) {
        Dialog(onDismissRequest = { showTx = false }) {
            Surface(shape = RoundedCornerShape(24.dp)) {
                TransactionForm(wallets, TxType.WITHDRAW, null, vm::submit) { showTx = false }
            }
        }
    }
}
