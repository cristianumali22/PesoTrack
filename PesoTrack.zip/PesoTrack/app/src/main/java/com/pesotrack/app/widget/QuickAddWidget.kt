package com.pesotrack.app.widget

import android.content.Context
import android.content.Intent
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.GlanceTheme
import androidx.glance.action.Action
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.action.actionStartActivity
import androidx.glance.appwidget.cornerRadius
import androidx.glance.appwidget.provideContent
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Box
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.layout.width
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextAlign
import androidx.glance.text.TextStyle
import com.pesotrack.app.QuickAddActivity
import com.pesotrack.app.data.AppDatabase
import com.pesotrack.app.data.Money

class QuickAddWidget : GlanceAppWidget() {

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val total = AppDatabase.get(context).walletDao().getAll()
            .filter { it.currency == "PHP" }.sumOf { it.balance }
        provideContent {
            GlanceTheme { Content(context, total) }
        }
    }

    @Composable
    private fun Content(context: Context, total: Long) {
        fun launch(type: String) = actionStartActivity(
            Intent(context, QuickAddActivity::class.java)
                .setAction("com.pesotrack.QUICK_ADD_$type")
                .putExtra(QuickAddActivity.EXTRA_TYPE, type)
        )
        Column(
            modifier = GlanceModifier.fillMaxSize()
                .background(GlanceTheme.colors.widgetBackground)
                .cornerRadius(20.dp)
                .padding(16.dp),
        ) {
            Text(
                "TOTAL BALANCE",
                style = TextStyle(color = GlanceTheme.colors.onSurfaceVariant, fontSize = 11.sp, fontWeight = FontWeight.Medium),
            )
            Spacer(GlanceModifier.height(2.dp))
            Text(
                Money.format(total),
                style = TextStyle(color = GlanceTheme.colors.onSurface, fontSize = 26.sp, fontWeight = FontWeight.Bold),
            )
            Spacer(GlanceModifier.height(12.dp))
            Row(modifier = GlanceModifier.fillMaxWidth()) {
                WidgetButton("− Spend", launch("WITHDRAW"), GlanceModifier.defaultWeight())
                Spacer(GlanceModifier.width(8.dp))
                WidgetButton("+ Add", launch("DEPOSIT"), GlanceModifier.defaultWeight())
            }
            Spacer(GlanceModifier.height(8.dp))
            WidgetButton("⇄ Transfer", launch("TRANSFER"), GlanceModifier.fillMaxWidth())
        }
    }

    @Composable
    private fun WidgetButton(label: String, onClick: Action, modifier: GlanceModifier) {
        Box(
            modifier = modifier
                .background(GlanceTheme.colors.primaryContainer)
                .cornerRadius(14.dp)
                .clickable(onClick)
                .padding(vertical = 10.dp),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                label,
                style = TextStyle(
                    color = GlanceTheme.colors.onPrimaryContainer,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    textAlign = TextAlign.Center,
                ),
            )
        }
    }
}

class QuickAddWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = QuickAddWidget()
}
