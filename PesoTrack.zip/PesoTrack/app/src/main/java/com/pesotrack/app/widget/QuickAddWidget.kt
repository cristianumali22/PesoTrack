package com.pesotrack.app.widget

import android.content.Context
import android.content.Intent
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.Button
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.GlanceTheme
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.action.actionStartActivity
import androidx.glance.appwidget.provideContent
import androidx.glance.background
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.layout.width
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import com.pesotrack.app.QuickAddActivity
import com.pesotrack.app.data.AppDatabase
import com.pesotrack.app.data.Money

class QuickAddWidget : GlanceAppWidget() {

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val total = AppDatabase.get(context).walletDao().getAll()
            .filter { it.currency == "PHP" }.sumOf { it.balance }
        provideContent {
            GlanceTheme { Content(context, total) }
        }
    }

    @Composable
    private fun Content(context: Context, total: Long) {
        fun launch(type: String) = actionStartActivity(
            Intent(context, QuickAddActivity::class.java)
                .setAction("com.pesotrack.QUICK_ADD_$type")
                .putExtra(QuickAddActivity.EXTRA_TYPE, type)
        )
        Column(
            modifier = GlanceModifier.fillMaxSize().background(GlanceTheme.colors.widgetBackground).padding(12.dp),
        ) {
            Text("Total balance", style = TextStyle(color = GlanceTheme.colors.onSurfaceVariant, fontSize = 12.sp))
            Text(
                Money.format(total),
                style = TextStyle(color = GlanceTheme.colors.onSurface, fontSize = 22.sp, fontWeight = FontWeight.Bold),
            )
            Spacer(GlanceModifier.height(8.dp))
            Row(modifier = GlanceModifier.fillMaxWidth()) {
                Button("− Spend", onClick = launch("WITHDRAW"), modifier = GlanceModifier.defaultWeight())
                Spacer(GlanceModifier.width(8.dp))
                Button("+ Add", onClick = launch("DEPOSIT"), modifier = GlanceModifier.defaultWeight())
            }
        }
    }
}

class QuickAddWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = QuickAddWidget()
}
